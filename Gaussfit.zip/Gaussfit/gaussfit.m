function [estimates, model] = gaussfit(xdata, ydata, v0)
model = @expfun;
estimates = fminsearch(model, v0);
    function [sse, FittedCurve] = expfun(v)
        a = v(1);
        b = v(2);
        c = v(3);
        FittedCurve =  a * exp(-(xdata-b).^2 / 2 / c / c);
        ErrorVector = FittedCurve - ydata;
        sse = sum(ErrorVector .^ 2);
    end
end