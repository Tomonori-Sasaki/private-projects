function varargout = GaussFittingXY(varargin)
% GAUSSFITTINGXY MATLAB code for GaussFittingXY.fig
%      GAUSSFITTINGXY, by itself, creates a new GAUSSFITTINGXY or raises the existing
%      singleton*.
%
%      H = GAUSSFITTINGXY returns the handle to a new GAUSSFITTINGXY or the handle to
%      the existing singleton*.
%
%      GAUSSFITTINGXY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GAUSSFITTINGXY.M with the given input arguments.
%
%      GAUSSFITTINGXY('Property','Value',...) creates a new GAUSSFITTINGXY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GaussFittingXY_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GaussFittingXY_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GaussFittingXY

% Last Modified by GUIDE v2.5 23-Oct-2015 11:45:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GaussFittingXY_OpeningFcn, ...
                   'gui_OutputFcn',  @GaussFittingXY_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GaussFittingXY is made visible.
function GaussFittingXY_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GaussFittingXY (see VARARGIN)

% Choose default command line output for GaussFittingXY
handles.output = hObject;
handles.val = [];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GaussFittingXY wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GaussFittingXY_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
PathName = uigetdir;
if PathName==0;
    return
end
cd (PathName);
set(handles.edit16,'String',num2str(PathName));



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A1 = imread('1.bmp');
A2 = imread('2.bmp');
A3 = imread('3.bmp');
A4 = imread('4.bmp');
A5 = imread('5.bmp');

B = imread('b1.bmp');
C = imread('b2.bmp');
D = imread('b3.bmp');

E1 = double(A1);
E2 = double(A2);
E3 = double(A3);
E4 = double(A4);
E5 = double(A5);

F = double(B);
G = double(C);
H = double(D);

I1 = E1-(F+G+H)/3;
I2 = E2-(F+G+H)/3;
I3 = E3-(F+G+H)/3;
I4 = E4-(F+G+H)/3;
I5 = E5-(F+G+H)/3;

J1 = abs(I1);
J2 = abs(I2);
J3 = abs(I3);
J4 = abs(I4);
J5 = abs(I5);

K1 = uint8(J1);
K2 = uint8(J2);
K3 = uint8(J3);
K4 = uint8(J4);
K5 = uint8(J5);

imwrite(K1,'bsub1.bmp');
imwrite(K2,'bsub2.bmp');
imwrite(K3,'bsub3.bmp');
imwrite(K4,'bsub4.bmp');
imwrite(K5,'bsub5.bmp');

X1 = sum(I1);
X2 = sum(I2);
X3 = sum(I3);
X4 = sum(I4);
X5 = sum(I5);

xdata = (0:1:655);
ydata1 = X1;
ydata2 = X2;
ydata3 = X3;
ydata4 = X4;
ydata5 = X5;

[a01,b01] = max(X1);
[a02,b02] = max(X2);
[a03,b03] = max(X3);
[a04,b04] = max(X4);
[a05,b05] = max(X5);

c01 = 0.39894*(max(X1)-min(X1))*mean(X1)/(max(X1)+10^(-100));
c02 = 0.39894*(max(X2)-min(X2))*mean(X2)/(max(X2)+10^(-100));
c03 = 0.39894*(max(X3)-min(X3))*mean(X3)/(max(X3)+10^(-100));
c04 = 0.39894*(max(X4)-min(X4))*mean(X4)/(max(X4)+10^(-100));
c05 = 0.39894*(max(X5)-min(X5))*mean(X5)/(max(X5)+10^(-100));

v01 = [a01 b01 c01];
v02 = [a02 b02 c02];
v03 = [a03 b03 c03];
v04 = [a04 b04 c04];
v05 = [a05 b05 c05];

if(isempty(handles.val) ~= 1)
    [estimates, model] = gaussfit(xdata, ydata1, v01);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes1, xdata/handles.val, ydata1, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes1, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes1, 'Brightness [pixels]')
    title(handles.axes1, ['Fitting Result 1']);
    %legend(handles.axes1, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes1, 'Data', ['Gauss Fitting'])
    a1 = estimates(1) ;
    set(handles.edit1,'String',num2str(a1));
    b1 = estimates(2)/handles.val ;
    set(handles.edit2,'String',num2str(b1));
    c1 = estimates(3)/handles.val ;
    set(handles.edit3,'String',num2str(c1));
    v1 = [a1 b1 c1];
    csvwrite('1X.txt',X1);
    
    [estimates, model] = gaussfit(xdata, ydata2, v02);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes2, xdata/handles.val, ydata2, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes2, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes2, 'Brightness [pixels]')
    title(handles.axes2, ['Fitting Result 2']);
    %legend(handles.axes2, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes2, 'Data', ['Gauss Fitting'])
    a2 = estimates(1) ;
    set(handles.edit4,'String',num2str(a2));
    b2 = estimates(2)/handles.val ;
    set(handles.edit5,'String',num2str(b2));
    c2 = estimates(3)/handles.val ;
    set(handles.edit6,'String',num2str(c2));
    v2 = [a2 b2 c2];
    csvwrite('2X.txt',X2);

    [estimates, model] = gaussfit(xdata, ydata3, v03);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes3, xdata/handles.val, ydata3, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes3, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes3, 'Brightness [pixels]')
    title(handles.axes3, ['Fitting Result 3']);
    %legend(handles.axes3, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes3, 'Data', ['Gauss Fitting'])
    a3 = estimates(1) ;
    set(handles.edit7,'String',num2str(a3));
    b3 = estimates(2)/handles.val ;
    set(handles.edit8,'String',num2str(b3));
    c3 = estimates(3)/handles.val ;
    set(handles.edit9,'String',num2str(c3));
    v3 = [a3 b3 c3];
    csvwrite('3X.txt',X3);

    [estimates, model] = gaussfit(xdata, ydata4, v04);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes4, xdata/handles.val, ydata4, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes4, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes4, 'Brightness [pixels]')
    title(handles.axes4, ['Fitting Result 4']);
    %legend(handles.axes4, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes4, 'Data', ['Gauss Fitting'])
    a4 = estimates(1) ;
    set(handles.edit10,'String',num2str(a4));
    b4 = estimates(2)/handles.val ;
    set(handles.edit11,'String',num2str(b4));
    c4 = estimates(3)/handles.val ;
    set(handles.edit12,'String',num2str(c4));
    v4 = [a4 b4 c4];
    csvwrite('4X.txt',X4);
    
    [estimates, model] = gaussfit(xdata, ydata5, v05);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes5, xdata/handles.val, ydata5, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes5, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes5, 'Brightness [pixels]')
    title(handles.axes5, ['Fitting Result 5']);
    %legend(handles.axes5, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes5, 'Data', ['Gauss Fitting'])
    a5 = estimates(1) ;
    set(handles.edit13,'String',num2str(a5));
    b5 = estimates(2)/handles.val ;
    set(handles.edit14,'String',num2str(b5));
    c5 = estimates(3)/handles.val ;
    set(handles.edit15,'String',num2str(c5));
    v5 = [a5 b5 c5];
    csvwrite('5X.txt',X5);

    I = (E1+E2+E3+E4+E5)/5-(F+G+H)/3;
    J = abs(I);
    K = uint8(J);
    imwrite(K,'bsubave.bmp');

    Vx = vertcat(v1,v2,v3,v4,v5);
    csvwrite('Xana.txt',Vx);
    Vxave = mean(abs(Vx));
    Vxerror = std(abs(Vx))/sqrt(5);
    Vxavestd = horzcat(Vxave, Vxerror);
    csvwrite('Xanaavestd.txt',Vxavestd);
end 

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A1 = imread('1.bmp');
A2 = imread('2.bmp');
A3 = imread('3.bmp');
A4 = imread('4.bmp');
A5 = imread('5.bmp');

B = imread('b1.bmp');
C = imread('b2.bmp');
D = imread('b3.bmp');

E1 = double(A1);
E2 = double(A2);
E3 = double(A3);
E4 = double(A4);
E5 = double(A5);

F = double(B);
G = double(C);
H = double(D);

I1 = E1-(F+G+H)/3;
I2 = E2-(F+G+H)/3;
I3 = E3-(F+G+H)/3;
I4 = E4-(F+G+H)/3;
I5 = E5-(F+G+H)/3;

J1 = abs(I1);
J2 = abs(I2);
J3 = abs(I3);
J4 = abs(I4);
J5 = abs(I5);

K1 = uint8(J1);
K2 = uint8(J2);
K3 = uint8(J3);
K4 = uint8(J4);
K5 = uint8(J5);

imwrite(K1,'bsub1.bmp');
imwrite(K2,'bsub2.bmp');
imwrite(K3,'bsub3.bmp');
imwrite(K4,'bsub4.bmp');
imwrite(K5,'bsub5.bmp');

Y1 = sum(I1,2);
Y2 = sum(I2,2);
Y3 = sum(I3,2);
Y4 = sum(I4,2);
Y5 = sum(I5,2);

xdata1 = Y1;
xdata2 = Y2;
xdata3 = Y3;
xdata4 = Y4;
xdata5 = Y5;
ydata = transpose(0:1:493);

[a01,b01] = max(Y1);
[a02,b02] = max(Y2);
[a03,b03] = max(Y3);
[a04,b04] = max(Y4);
[a05,b05] = max(Y5);

c01 = 0.39894*(max(Y1)-min(Y1))*mean(Y1)/(max(Y1)+10^(-100));
c02 = 0.39894*(max(Y2)-min(Y2))*mean(Y2)/(max(Y2)+10^(-100));
c03 = 0.39894*(max(Y3)-min(Y3))*mean(Y3)/(max(Y3)+10^(-100));
c04 = 0.39894*(max(Y4)-min(Y4))*mean(Y4)/(max(Y4)+10^(-100));
c05 = 0.39894*(max(Y5)-min(Y5))*mean(Y5)/(max(Y5)+10^(-100));

v01 = [a01 b01 c01];
v02 = [a02 b02 c02];
v03 = [a03 b03 c03];
v04 = [a04 b04 c04];
v05 = [a05 b05 c05];

if(isempty(handles.val) ~= 1)
    [estimates, model] = gaussfit(ydata, xdata1, v01);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes1, xdata1, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes1, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes1, 'Brightness [pixels]')
    title(handles.axes1, ['Fitting Result 1']);
    legend(handles.axes1, 'Data', ['Gauss Fitting'])
    a1 = estimates(1) ;
    set(handles.edit1,'String',num2str(a1));
    b1 = estimates(2)/handles.val ;
    set(handles.edit2,'String',num2str(b1));
    c1 = estimates(3)/handles.val ;
    set(handles.edit3,'String',num2str(c1));
    v1 = [a1 b1 c1];
    csvwrite('1Y.txt',Y1);

    [estimates, model] = gaussfit(ydata, xdata2, v02);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes2, xdata2, ydata/handles.val, '*', FittedCurve, ydata/handles.val,'r')
    xlabel(handles.axes2, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes2, 'Brightness [pixels]')
    title(handles.axes2, ['Fitting Result 2']);
    legend(handles.axes2, 'Data', ['Gauss Fitting'])
    a2 = estimates(1) ;
    set(handles.edit4,'String',num2str(a2));
    b2 = estimates(2)/handles.val ;
    set(handles.edit5,'String',num2str(b2));
    c2 = estimates(3)/handles.val ;
    set(handles.edit6,'String',num2str(c2));
    v2 = [a2 b2 c2];
    csvwrite('2Y.txt',Y2);
 
    [estimates, model] = gaussfit(ydata, xdata3, v03);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes3, xdata3, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes3, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes3, 'Brightness [pixels]')
    title(handles.axes3, ['Fitting Result 3']);
    legend(handles.axes3, 'Data', ['Gauss Fitting'])
    a3 = estimates(1) ;
    set(handles.edit7,'String',num2str(a3));
    b3 = estimates(2)/handles.val ;
    set(handles.edit8,'String',num2str(b3));
    c3 = estimates(3)/handles.val ;
    set(handles.edit9,'String',num2str(c3));
    v3 = [a3 b3 c3];
    csvwrite('3Y.txt',Y3);

    [estimates, model] = gaussfit(ydata, xdata4, v04);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes4, xdata4, ydata/handles.val, '*', FittedCurve, ydata/handles.val,'r')
    xlabel(handles.axes4, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes4, 'Brightness [pixels]')
    title(handles.axes4, ['Fitting Result 4']);
    legend(handles.axes4, 'Data', ['Gauss Fitting'])
    a4 = estimates(1) ;
    set(handles.edit10,'String',num2str(a4));
    b4 = estimates(2)/handles.val ;
    set(handles.edit11,'String',num2str(b4));
    c4 = estimates(3)/handles.val ;
    set(handles.edit12,'String',num2str(c4));
    v4 = [a4 b4 c4];
    csvwrite('4Y.txt',Y4);
    
    [estimates, model] = gaussfit(ydata, xdata5, v05);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes5, xdata5, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes5, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes5, 'Brightness [pixels]')
    title(handles.axes5, ['Fitting Result 5']);
    legend(handles.axes5, 'Data', ['Gauss Fitting'])
    a5 = estimates(1) ;
    set(handles.edit13,'String',num2str(a5));
    b5 = estimates(2)/handles.val ;
    set(handles.edit14,'String',num2str(b5));
    c5 = estimates(3)/handles.val ;
    set(handles.edit15,'String',num2str(c5));
    v5 = [a5 b5 c5];
    csvwrite('5Y.txt',Y5);

    I = (E1+E2+E3+E4+E5)/5-(F+G+H)/3;
    J = abs(I);
    K = uint8(J);
    imwrite(K,'bsubave.bmp');
    
    Vy = vertcat(v1,v2,v3,v4,v5);
    csvwrite('Yana.txt',Vy);
    Vyave = mean(abs(Vy));
    Vyerror = std(abs(Vy))/sqrt(5);
    Vyavestd = horzcat(Vyave, Vyerror);
    csvwrite('Yanaavestd.txt',Vyavestd);
end
 

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A1 = imread('1.bmp');
A2 = imread('2.bmp');
A3 = imread('3.bmp');
A4 = imread('4.bmp');
A5 = imread('5.bmp');

B = imread('b1.bmp');
C = imread('b2.bmp');
D = imread('b3.bmp');

E1 = double(A1);
E2 = double(A2);
E3 = double(A3);
E4 = double(A4);
E5 = double(A5);

F = double(B);
G = double(C);
H = double(D);

I1 = E1-(F+G+H)/3;
I2 = E2-(F+G+H)/3;
I3 = E3-(F+G+H)/3;
I4 = E4-(F+G+H)/3;
I5 = E5-(F+G+H)/3;

X1 = sum(I1);
X2 = sum(I2);
X3 = sum(I3);
X4 = sum(I4);
X5 = sum(I5);

xdata = (0:1:655);
ydata1 = X1;
ydata2 = X2;
ydata3 = X3;
ydata4 = X4;
ydata5 = X5;

[a01,b01] = max(X1);
[a02,b02] = max(X2);
[a03,b03] = max(X3);
[a04,b04] = max(X4);
[a05,b05] = max(X5);

c01 = 0.39894*(max(X1)-min(X1))*mean(X1)/(max(X1)+10^(-100));
c02 = 0.39894*(max(X2)-min(X2))*mean(X2)/(max(X2)+10^(-100));
c03 = 0.39894*(max(X3)-min(X3))*mean(X3)/(max(X3)+10^(-100));
c04 = 0.39894*(max(X4)-min(X4))*mean(X4)/(max(X4)+10^(-100));
c05 = 0.39894*(max(X5)-min(X5))*mean(X5)/(max(X5)+10^(-100));

v01 = [a01 b01 c01];
v02 = [a02 b02 c02];
v03 = [a03 b03 c03];
v04 = [a04 b04 c04];
v05 = [a05 b05 c05];

if(isempty(handles.val) ~= 1)
    [estimates, model] = gaussfit(xdata, ydata1, v01);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes1, xdata/handles.val, ydata1, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes1, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes1, 'Brightness [pixels]')
    title(handles.axes1, ['Fitting Result 1']);
    %legend(handles.axes1, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes1, 'Data', ['Gauss Fitting'])
    a1 = estimates(1) ;
    set(handles.edit1,'String',num2str(a1));
    b1 = estimates(2)/handles.val ;
    set(handles.edit2,'String',num2str(b1));
    c1 = estimates(3)/handles.val ;
    set(handles.edit3,'String',num2str(c1));
    v1 = [a1 b1 c1];
    
    [estimates, model] = gaussfit(xdata, ydata2, v02);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes2, xdata/handles.val, ydata2, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes2, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes2, 'Brightness [pixels]')
    title(handles.axes2, ['Fitting Result 2']);
    %legend(handles.axes2, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes2, 'Data', ['Gauss Fitting'])
    a2 = estimates(1) ;
    set(handles.edit4,'String',num2str(a2));
    b2 = estimates(2)/handles.val ;
    set(handles.edit5,'String',num2str(b2));
    c2 = estimates(3)/handles.val ;
    set(handles.edit6,'String',num2str(c2));
    v2 = [a2 b2 c2];

    [estimates, model] = gaussfit(xdata, ydata3, v03);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes3, xdata/handles.val, ydata3, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes3, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes3, 'Brightness [pixels]')
    title(handles.axes3, ['Fitting Result 3']);
    %legend(handles.axes3, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes3, 'Data', ['Gauss Fitting'])
    a3 = estimates(1) ;
    set(handles.edit7,'String',num2str(a3));
    b3 = estimates(2)/handles.val ;
    set(handles.edit8,'String',num2str(b3));
    c3 = estimates(3)/handles.val ;
    set(handles.edit9,'String',num2str(c3));
    v3 = [a3 b3 c3];

    [estimates, model] = gaussfit(xdata, ydata4, v04);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes4, xdata/handles.val, ydata4, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes4, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes4, 'Brightness [pixels]')
    title(handles.axes4, ['Fitting Result 4']);
    %legend(handles.axes4, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes4, 'Data', ['Gauss Fitting'])
    a4 = estimates(1) ;
    set(handles.edit10,'String',num2str(a4));
    b4 = estimates(2)/handles.val ;
    set(handles.edit11,'String',num2str(b4));
    c4 = estimates(3)/handles.val ;
    set(handles.edit12,'String',num2str(c4));
    v4 = [a4 b4 c4];
    
    [estimates, model] = gaussfit(xdata, ydata5, v05);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes5, xdata/handles.val, ydata5, '*', xdata/handles.val, FittedCurve, 'r')
    xlabel(handles.axes5, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes5, 'Brightness [pixels]')
    title(handles.axes5, ['Fitting Result 5']);
    %legend(handles.axes5, 'Data', ['Gauss Fitting'], 'Location','NorthWest')
    legend(handles.axes5, 'Data', ['Gauss Fitting'])
    a5 = estimates(1) ;
    set(handles.edit13,'String',num2str(a5));
    b5 = estimates(2)/handles.val ;
    set(handles.edit14,'String',num2str(b5));
    c5 = estimates(3)/handles.val ;
    set(handles.edit15,'String',num2str(c5));
    v5 = [a5 b5 c5];
end 

 
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A1 = imread('1.bmp');
A2 = imread('2.bmp');
A3 = imread('3.bmp');
A4 = imread('4.bmp');
A5 = imread('5.bmp');

B = imread('b1.bmp');
C = imread('b2.bmp');
D = imread('b3.bmp');

E1 = double(A1);
E2 = double(A2);
E3 = double(A3);
E4 = double(A4);
E5 = double(A5);

F = double(B);
G = double(C);
H = double(D);

I1 = E1-(F+G+H)/3;
I2 = E2-(F+G+H)/3;
I3 = E3-(F+G+H)/3;
I4 = E4-(F+G+H)/3;
I5 = E5-(F+G+H)/3;

Y1 = sum(I1,2);
Y2 = sum(I2,2);
Y3 = sum(I3,2);
Y4 = sum(I4,2);
Y5 = sum(I5,2);

xdata1 = Y1;
xdata2 = Y2;
xdata3 = Y3;
xdata4 = Y4;
xdata5 = Y5;
ydata = transpose(0:1:493);

[a01,b01] = max(Y1);
[a02,b02] = max(Y2);
[a03,b03] = max(Y3);
[a04,b04] = max(Y4);
[a05,b05] = max(Y5);

c01 = 0.39894*(max(Y1)-min(Y1))*mean(Y1)/(max(Y1)+10^(-100));
c02 = 0.39894*(max(Y2)-min(Y2))*mean(Y2)/(max(Y2)+10^(-100));
c03 = 0.39894*(max(Y3)-min(Y3))*mean(Y3)/(max(Y3)+10^(-100));
c04 = 0.39894*(max(Y4)-min(Y4))*mean(Y4)/(max(Y4)+10^(-100));
c05 = 0.39894*(max(Y5)-min(Y5))*mean(Y5)/(max(Y5)+10^(-100));

v01 = [a01 b01 c01];
v02 = [a02 b02 c02];
v03 = [a03 b03 c03];
v04 = [a04 b04 c04];
v05 = [a05 b05 c05];

if(isempty(handles.val) ~= 1)
    [estimates, model] = gaussfit(ydata, xdata1, v01);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes1, xdata1, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes1, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes1, 'Brightness [pixels]')
    title(handles.axes1, ['Fitting Result 1']);
    legend(handles.axes1, 'Data', ['Gauss Fitting'])
    a1 = estimates(1) ;
    set(handles.edit1,'String',num2str(a1));
    b1 = estimates(2)/handles.val ;
    set(handles.edit2,'String',num2str(b1));
    c1 = estimates(3)/handles.val ;
    set(handles.edit3,'String',num2str(c1));
    v1 = [a1 b1 c1];

    [estimates, model] = gaussfit(ydata, xdata2, v02);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes2, xdata2, ydata/handles.val, '*', FittedCurve, ydata/handles.val,'r')
    xlabel(handles.axes2, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes2, 'Brightness [pixels]')
    title(handles.axes2, ['Fitting Result 2']);
    legend(handles.axes2, 'Data', ['Gauss Fitting'])
    a2 = estimates(1) ;
    set(handles.edit4,'String',num2str(a2));
    b2 = estimates(2)/handles.val ;
    set(handles.edit5,'String',num2str(b2));
    c2 = estimates(3)/handles.val ;
    set(handles.edit6,'String',num2str(c2));
    v2 = [a2 b2 c2];
 
    [estimates, model] = gaussfit(ydata, xdata3, v03);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes3, xdata3, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes3, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes3, 'Brightness [pixels]')
    title(handles.axes3, ['Fitting Result 3']);
    legend(handles.axes3, 'Data', ['Gauss Fitting'])
    a3 = estimates(1) ;
    set(handles.edit7,'String',num2str(a3));
    b3 = estimates(2)/handles.val ;
    set(handles.edit8,'String',num2str(b3));
    c3 = estimates(3)/handles.val ;
    set(handles.edit9,'String',num2str(c3));
    v3 = [a3 b3 c3];

    [estimates, model] = gaussfit(ydata, xdata4, v04);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes4, xdata4, ydata/handles.val, '*', FittedCurve, ydata/handles.val,'r')
    xlabel(handles.axes4, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes4, 'Brightness [pixels]')
    title(handles.axes4, ['Fitting Result 4']);
    legend(handles.axes4, 'Data', ['Gauss Fitting'])
    a4 = estimates(1) ;
    set(handles.edit10,'String',num2str(a4));
    b4 = estimates(2)/handles.val ;
    set(handles.edit11,'String',num2str(b4));
    c4 = estimates(3)/handles.val ;
    set(handles.edit12,'String',num2str(c4));
    v4 = [a4 b4 c4];
    
    [estimates, model] = gaussfit(ydata, xdata5, v05);
    [sse, FittedCurve] = model(estimates);
    plot(handles.axes5, xdata5, ydata/handles.val, '*', FittedCurve, ydata/handles.val, 'r')
    xlabel(handles.axes5, 'Longitudinal Beam Position or Energy [pixels]')
    ylabel(handles.axes5, 'Brightness [pixels]')
    title(handles.axes5, ['Fitting Result 5']);
    legend(handles.axes5, 'Data', ['Gauss Fitting'])
    a5 = estimates(1) ;
    set(handles.edit13,'String',num2str(a5));
    b5 = estimates(2)/handles.val ;
    set(handles.edit14,'String',num2str(b5));
    c5 = estimates(3)/handles.val ;
    set(handles.edit15,'String',num2str(c5));
    v5 = [a5 b5 c5];
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double
handles.val=str2double(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
