for MM=1:9    
IIy(:,:,MM) = I1(:,:,137+22*MM);
IIIy(:,:,MM) = max(max(IIy(:,:,MM)));
IIIIy(:,:,MM) = IIy(:,:,MM)/IIIy(:,:,MM)*128;
end;
YSLICE = uint8(IIIIy);
subplot(3,3,1),imshow(YSLICE(:,:,1)),title('159pixel')
subplot(3,3,2),imshow(YSLICE(:,:,2)),title('181pixel')
subplot(3,3,3),imshow(YSLICE(:,:,3)),title('203pixel')
subplot(3,3,4),imshow(YSLICE(:,:,4)),title('225pixel')
subplot(3,3,5),imshow(YSLICE(:,:,5)),title('247pixel')
subplot(3,3,6),imshow(YSLICE(:,:,6)),title('269pixel')
subplot(3,3,7),imshow(YSLICE(:,:,7)),title('291pixel')
subplot(3,3,8),imshow(YSLICE(:,:,8)),title('313pixel')
subplot(3,3,9),imshow(YSLICE(:,:,9)),title('335pixel')
