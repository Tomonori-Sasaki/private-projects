for MM=1:9    
IIx(:,:,MM) = I5(:,:,288+8*MM);
IIIx(:,:,MM) = max(max(IIx(:,:,MM)));
IIIIx(:,:,MM) = IIx(:,:,MM)/IIIx(:,:,MM)*128;
end;
XSLICE = uint8(IIIIx);
subplot(3,3,1),imshow(XSLICE(:,:,1)),title('296pixel')
subplot(3,3,2),imshow(XSLICE(:,:,2)),title('304pixel')
subplot(3,3,3),imshow(XSLICE(:,:,3)),title('312pixel')
subplot(3,3,4),imshow(XSLICE(:,:,4)),title('320pixel')
subplot(3,3,5),imshow(XSLICE(:,:,5)),title('328pixel')
subplot(3,3,6),imshow(XSLICE(:,:,6)),title('336pixel')
subplot(3,3,7),imshow(XSLICE(:,:,7)),title('344pixel')
subplot(3,3,8),imshow(XSLICE(:,:,8)),title('352pixel')
subplot(3,3,9),imshow(XSLICE(:,:,9)),title('360pixel')
