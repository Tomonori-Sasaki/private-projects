for MM=1:9    
IIz(:,:,MM) = I12(:,:,288+8*MM);
IIIz(:,:,MM) = max(max(IIz(:,:,MM)));
IIIIz(:,:,MM) = IIz(:,:,MM)/IIIz(:,:,MM)*128;
end;
ZSLICE = uint8(IIIIz);
subplot(3,3,1),imshow(ZSLICE(:,:,1)),title('296pixel')
subplot(3,3,2),imshow(ZSLICE(:,:,2)),title('304pixel')
subplot(3,3,3),imshow(ZSLICE(:,:,3)),title('312pixel')
subplot(3,3,4),imshow(ZSLICE(:,:,4)),title('320pixel')
subplot(3,3,5),imshow(ZSLICE(:,:,5)),title('328pixel')
subplot(3,3,6),imshow(ZSLICE(:,:,6)),title('336pixel')
subplot(3,3,7),imshow(ZSLICE(:,:,7)),title('344pixel')
subplot(3,3,8),imshow(ZSLICE(:,:,8)),title('352pixel')
subplot(3,3,9),imshow(ZSLICE(:,:,9)),title('360pixel')
