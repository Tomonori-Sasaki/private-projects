IIx = zeros(494,656,9);
IIIIx = zeros(494,656,9);
IIy = zeros(656,656,9);
IIIIy = zeros(656,656,9);
IIz = zeros(494,656,9);
IIIIz = zeros(494,656,9);


for MM=1:9    
IIx(:,:,MM) = I5(:,:,288+8*MM);
IIIx = max(max(IIx(:,:,MM)));
IIIIx(:,:,MM) = IIx(:,:,MM)./IIIx*128;
end;
XSLICE = uint8(IIIIx);
figure
subplot(3,3,1),imshow(XSLICE(:,:,1)),title('1.66mm')
subplot(3,3,2),imshow(XSLICE(:,:,2)),title('1.24mm')
subplot(3,3,3),imshow(XSLICE(:,:,3)),title('0.83mm')
subplot(3,3,4),imshow(XSLICE(:,:,4)),title('0.41mm')
subplot(3,3,5),imshow(XSLICE(:,:,5)),title('0.00mm')
subplot(3,3,6),imshow(XSLICE(:,:,6)),title('-0.41mm')
subplot(3,3,7),imshow(XSLICE(:,:,7)),title('-0.83mm')
subplot(3,3,8),imshow(XSLICE(:,:,8)),title('-1.24mm')
subplot(3,3,9),imshow(XSLICE(:,:,9)),title('-1.66mm')
saveas(gcf,'Xslice.png')

imwrite(XSLICE(:,:,1),'x1.66mm.bmp')
imwrite(XSLICE(:,:,2),'x1.24mm.bmp')
imwrite(XSLICE(:,:,3),'x0.83mm.bmp')
imwrite(XSLICE(:,:,4),'x0.41mm.bmp')
imwrite(XSLICE(:,:,5),'x0.00mm.bmp')
imwrite(XSLICE(:,:,6),'x-0.41mm.bmp')
imwrite(XSLICE(:,:,7),'x-0.83mm.bmp')
imwrite(XSLICE(:,:,8),'x-1.24mm.bmp')
imwrite(XSLICE(:,:,9),'x-1.66mm.bmp')



for MM=1:9    
IIy(:,:,MM) = I1(:,:,137+22*MM);
IIIy = max(max(IIy(:,:,MM)));
IIIIy(:,:,MM) = IIy(:,:,MM)./IIIy*128;
end;
YSLICE = uint8(IIIIy);
figure
subplot(3,3,1),imshow(YSLICE(:,:,1)),title('4.55mm')
subplot(3,3,2),imshow(YSLICE(:,:,2)),title('3.41mm')
subplot(3,3,3),imshow(YSLICE(:,:,3)),title('2.28mm')
subplot(3,3,4),imshow(YSLICE(:,:,4)),title('1.14mm')
subplot(3,3,5),imshow(YSLICE(:,:,5)),title('0.00mm')
subplot(3,3,6),imshow(YSLICE(:,:,6)),title('-1.14mm')
subplot(3,3,7),imshow(YSLICE(:,:,7)),title('-2.28mm')
subplot(3,3,8),imshow(YSLICE(:,:,8)),title('-3.41mm')
subplot(3,3,9),imshow(YSLICE(:,:,9)),title('-4.55mm')
saveas(gcf,'Yslice.png')

imwrite(YSLICE(:,:,1),'y4.55mm.bmp')
imwrite(YSLICE(:,:,2),'y3.41mm.bmp')
imwrite(YSLICE(:,:,3),'y2.28mm.bmp')
imwrite(YSLICE(:,:,4),'y1.14mm.bmp')
imwrite(YSLICE(:,:,5),'y0.00mm.bmp')
imwrite(YSLICE(:,:,6),'y-1.14mm.bmp')
imwrite(YSLICE(:,:,7),'y-2.28mm.bmp')
imwrite(YSLICE(:,:,8),'y-3.41mm.bmp')
imwrite(YSLICE(:,:,9),'y-4.55mm.bmp')


for MM=1:9    
IIz(:,:,MM) = I12(:,:,288+8*MM);
IIIz = max(max(IIz(:,:,MM)));
IIIIz(:,:,MM) = IIz(:,:,MM)./IIIz*128;
end;
ZSLICE = uint8(IIIIz);
figure
subplot(3,3,1),imshow(ZSLICE(:,:,1)),title('1.66mm')
subplot(3,3,2),imshow(ZSLICE(:,:,2)),title('1.24mm')
subplot(3,3,3),imshow(ZSLICE(:,:,3)),title('0.83mm')
subplot(3,3,4),imshow(ZSLICE(:,:,4)),title('0.41mm')
subplot(3,3,5),imshow(ZSLICE(:,:,5)),title('0.00mm')
subplot(3,3,6),imshow(ZSLICE(:,:,6)),title('-0.41mm')
subplot(3,3,7),imshow(ZSLICE(:,:,7)),title('-0.83mm')
subplot(3,3,8),imshow(ZSLICE(:,:,8)),title('-1.24mm')
subplot(3,3,9),imshow(ZSLICE(:,:,9)),title('-1.66mm')
saveas(gcf,'Zslice.png')

imwrite(ZSLICE(:,:,1),'z1.66mm.bmp')
imwrite(ZSLICE(:,:,2),'z1.24mm.bmp')
imwrite(ZSLICE(:,:,3),'z0.83mm.bmp')
imwrite(ZSLICE(:,:,4),'z0.41mm.bmp')
imwrite(ZSLICE(:,:,5),'z0.00mm.bmp')
imwrite(ZSLICE(:,:,6),'z-0.41mm.bmp')
imwrite(ZSLICE(:,:,7),'z-0.83mm.bmp')
imwrite(ZSLICE(:,:,8),'z-1.24mm.bmp')
imwrite(ZSLICE(:,:,9),'z-1.66mm.bmp')
