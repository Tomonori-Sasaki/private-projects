clear;
%�摜�̓ǂݍ���
A2 = imread('-78.bmp');
A3 = imread('-76.bmp');
A4 = imread('-74.bmp');
A5 = imread('-72.bmp');
A6 = imread('-70.bmp');
A7 = imread('-68.bmp');
A8 = imread('-66.bmp');
A9 = imread('-64.bmp');
A10 = imread('-62.bmp');
A11 = imread('-60.bmp');
A12 = imread('-58.bmp');
A13 = imread('-56.bmp');
A14 = imread('-54.bmp');
A15 = imread('-52.bmp');
A16 = imread('-50.bmp');
A17 = imread('-48.bmp');
A18 = imread('-46.bmp');
A19 = imread('-44.bmp');
A20 = imread('-42.bmp');
A21 = imread('-40.bmp');
A22 = imread('-38.bmp');
A23 = imread('-36.bmp');
A24 = imread('-34.bmp');
A25 = imread('-32.bmp');
A26 = imread('-30.bmp');
A27 = imread('-28.bmp');
A28 = imread('-26.bmp');
A29 = imread('-24.bmp');
A30 = imread('-22.bmp');
A31 = imread('-20.bmp');
A32 = imread('-18.bmp');
A33 = imread('-16.bmp');
A34 = imread('-14.bmp');
A35 = imread('-12.bmp');
A36 = imread('-10.bmp');
A37 = imread('-8.bmp');
A38 = imread('-6.bmp');
A39 = imread('-4.bmp');
A40 = imread('-2.bmp');
A41 = imread('off.bmp');
A42 = imread('+2.bmp');
A43 = imread('+4.bmp');
A44 = imread('+6.bmp');
A45 = imread('+8.bmp');
A46 = imread('+10.bmp');
A47 = imread('+12.bmp');
A48 = imread('+14.bmp');
A49 = imread('+16.bmp');
A50 = imread('+18.bmp');
A51 = imread('+20.bmp');
A52 = imread('+22.bmp');
A53 = imread('+24.bmp');
A54 = imread('+26.bmp');
A55 = imread('+28.bmp');
A56 = imread('+30.bmp');
A57 = imread('+32.bmp');
A58 = imread('+34.bmp');
A59 = imread('+36.bmp');
A60 = imread('+38.bmp');
A61 = imread('+40.bmp');
A62 = imread('+42.bmp');
A63 = imread('+44.bmp');
A64 = imread('+46.bmp');
A65 = imread('+48.bmp');
A66 = imread('+50.bmp');
A67 = imread('+52.bmp');
A68 = imread('+54.bmp');
A69 = imread('+56.bmp');
A70 = imread('+58.bmp');
A71 = imread('+60.bmp');
A72 = imread('+62.bmp');
A73 = imread('+64.bmp');
A74 = imread('+66.bmp');
A75 = imread('+68.bmp');
A76 = imread('+70.bmp');
A77 = imread('+72.bmp');
A78 = imread('+74.bmp');
A79 = imread('+76.bmp');
A80 = imread('+78.bmp');
A81 = imread('+80.bmp');

%uint����double�ւ̕ϊ�
B2 = double(A2);
B3 = double(A3);
B4 = double(A4);
B5 = double(A5);
B6 = double(A6);
B7 = double(A7);
B8 = double(A8);
B9 = double(A9);
B10 = double(A10);
B11 = double(A11);
B12 = double(A12);
B13 = double(A13);
B14 = double(A14);
B15 = double(A15);
B16 = double(A16);
B17 = double(A17);
B18 = double(A18);
B19 = double(A19);
B20 = double(A20);
B21 = double(A21);
B22 = double(A22);
B23 = double(A23);
B24 = double(A24);
B25 = double(A25);
B26 = double(A26);
B27 = double(A27);
B28 = double(A28);
B29 = double(A29);
B30 = double(A30);
B31 = double(A31);
B32 = double(A32);
B33 = double(A33);
B34 = double(A34);
B35 = double(A35);
B36 = double(A36);
B37 = double(A37);
B38 = double(A38);
B39 = double(A39);
B40 = double(A40);
B41 = double(A41);
B42 = double(A42);
B43 = double(A43);
B44 = double(A44);
B45 = double(A45);
B46 = double(A46);
B47 = double(A47);
B48 = double(A48);
B49 = double(A49);
B50 = double(A50);
B51 = double(A51);
B52 = double(A52);
B53 = double(A53);
B54 = double(A54);
B55 = double(A55);
B56 = double(A56);
B57 = double(A57);
B58 = double(A58);
B59 = double(A59);
B60 = double(A60);
B61 = double(A61);
B62 = double(A62);
B63 = double(A63);
B64= double(A64);
B65 = double(A65);
B66 = double(A66);
B67 = double(A67);
B68 = double(A68);
B69 = double(A69);
B70 = double(A70);
B71 = double(A71);
B72 = double(A72);
B73 = double(A73);
B74 = double(A74);
B75 = double(A75);
B76 = double(A76);
B77 = double(A77);
B78 = double(A78);
B79 = double(A79);
B80 = double(A80);
B81 = double(A81);

%�S�Ă̓��e�f�[�^���y�[�W���ƂɎ��߂�
BA = [B2	B3	B4	B5	B6	B7	B8	B9	B10	B11	B12	B13	B14	B15	B16	B17	B18	B19	B20	B21	B22	B23	B24	B25	B26	B27	B28	B29	B30	B31	B32	B33	B34	B35	B36	B37	B38	B39	B40	B41	B42	B43	B44	B45	B46	B47	B48	B49	B50	B51	B52	B53	B54	B55	B56	B57	B58	B59	B60	B61	B62	B63	B64	B65	B66	B67	B68	B69	B70	B71	B72	B73	B74	B75	B76	B77	B78	B79	B80	B81
];
BAA = zeros(494,656,80);
for N=1:80;
BAA(1:494,1:656,N) = BA(:,(656*(N-1)+1):(656*N));
end;

%���s�ړ�
ydata1=zeros(1,656,80);
ydata2=zeros(1,494,80);
BB1=sum(BAA);
BB2=permute(sum(BAA,2),[2,1,3]);
for N=1:80;
ydata1(:,:,N)=BB1(:,:,N);
ydata2(:,:,N)=BB2(:,:,N);
end;

xdata1=0:655;
xdata2=0:493;

Cx = zeros(1,3,80);
Cy = zeros(1,3,80);
Tx = zeros(1,1,80);
Ty = zeros(1,1,80);
C = zeros(494,656,80);
for N=1:80;
Cx(:,:,N)=gaussfit(xdata1,ydata1(:,:,N),10^3*[6.17,0.31,0.017]);
Cy(:,:,N)=gaussfit(xdata2,ydata2(:,:,N),10^3*[2.81,0.23,0.045]);


Tx(:,:,N)=round(327.5-Cx(1,2,N));
Ty(:,:,N)=round(246.5-Cy(1,2,N));


if Tx(:,:,N)>=0;
    if Ty(:,:,N)>=0;C(1+Ty(:,:,N):494,1+Tx(:,:,N):656,N)=BAA(1:494-Ty(:,:,N),1:656-Tx(:,:,N),N);
    else C(1:494+Ty(:,:,N),1+Tx(:,:,N):656,N)=BAA(1-Ty(:,:,N):494,1:656-Tx(:,:,N),N);
    end;
else if Ty(:,:,N)>=0;C(1+Ty(:,:,N):494,1:656+Tx(:,:,N),N)=BAA(1:494-Ty(:,:,N),1-Tx(:,:,N):656,N);
    else C(1:494+Ty(:,:,N),1:656+Tx(:,:,N),N)=BAA(1-Ty(:,:,N):494,1-Tx(:,:,N):656,N);
    end;
end
end;

%�C���[�W�̃T�C�Y�����ꂼ��Deflection������cos�Ɣ{����B
theta = -78:2:80;
C1 = uint8(C);
D = 656.*cos(theta.*(pi/180));
D1	=imresize(C1(:,:,1)	,[494,round(D(1,1))]);
D2	=imresize(C1(:,:,2)	,[494,round(D(1,2))]);
D3	=imresize(C1(:,:,3)	,[494,round(D(1,3))]);
D4	=imresize(C1(:,:,4)	,[494,round(D(1,4))]);
D5	=imresize(C1(:,:,5)	,[494,round(D(1,5))]);
D6	=imresize(C1(:,:,6)	,[494,round(D(1,6))]);
D7	=imresize(C1(:,:,7)	,[494,round(D(1,7))]);
D8	=imresize(C1(:,:,8)	,[494,round(D(1,8))]);
D9	=imresize(C1(:,:,9)	,[494,round(D(1,9))]);
D10	=imresize(C1(:,:,10)	,[494,round(D(1,10))]);
D11	=imresize(C1(:,:,11)	,[494,round(D(1,11))]);
D12	=imresize(C1(:,:,12)	,[494,round(D(1,12))]);
D13	=imresize(C1(:,:,13)	,[494,round(D(1,13))]);
D14	=imresize(C1(:,:,14)	,[494,round(D(1,14))]);
D15	=imresize(C1(:,:,15)	,[494,round(D(1,15))]);
D16	=imresize(C1(:,:,16)	,[494,round(D(1,16))]);
D17	=imresize(C1(:,:,17)	,[494,round(D(1,17))]);
D18	=imresize(C1(:,:,18)	,[494,round(D(1,18))]);
D19	=imresize(C1(:,:,19)	,[494,round(D(1,19))]);
D20	=imresize(C1(:,:,20)	,[494,round(D(1,20))]);
D21	=imresize(C1(:,:,21)	,[494,round(D(1,21))]);
D22	=imresize(C1(:,:,22)	,[494,round(D(1,22))]);
D23	=imresize(C1(:,:,23)	,[494,round(D(1,23))]);
D24	=imresize(C1(:,:,24)	,[494,round(D(1,24))]);
D25	=imresize(C1(:,:,25)	,[494,round(D(1,25))]);
D26	=imresize(C1(:,:,26)	,[494,round(D(1,26))]);
D27	=imresize(C1(:,:,27)	,[494,round(D(1,27))]);
D28	=imresize(C1(:,:,28)	,[494,round(D(1,28))]);
D29	=imresize(C1(:,:,29)	,[494,round(D(1,29))]);
D30	=imresize(C1(:,:,30)	,[494,round(D(1,30))]);
D31	=imresize(C1(:,:,31)	,[494,round(D(1,31))]);
D32	=imresize(C1(:,:,32)	,[494,round(D(1,32))]);
D33	=imresize(C1(:,:,33)	,[494,round(D(1,33))]);
D34	=imresize(C1(:,:,34)	,[494,round(D(1,34))]);
D35	=imresize(C1(:,:,35)	,[494,round(D(1,35))]);
D36	=imresize(C1(:,:,36)	,[494,round(D(1,36))]);
D37	=imresize(C1(:,:,37)	,[494,round(D(1,37))]);
D38	=imresize(C1(:,:,38)	,[494,round(D(1,38))]);
D39	=imresize(C1(:,:,39)	,[494,round(D(1,39))]);
D40	=imresize(C1(:,:,40)	,[494,round(D(1,40))]);
D41	=imresize(C1(:,:,41)	,[494,round(D(1,41))]);
D42	=imresize(C1(:,:,42)	,[494,round(D(1,42))]);
D43	=imresize(C1(:,:,43)	,[494,round(D(1,43))]);
D44	=imresize(C1(:,:,44)	,[494,round(D(1,44))]);
D45	=imresize(C1(:,:,45)	,[494,round(D(1,45))]);
D46	=imresize(C1(:,:,46)	,[494,round(D(1,46))]);
D47	=imresize(C1(:,:,47)	,[494,round(D(1,47))]);
D48	=imresize(C1(:,:,48)	,[494,round(D(1,48))]);
D49	=imresize(C1(:,:,49)	,[494,round(D(1,49))]);
D50	=imresize(C1(:,:,50)	,[494,round(D(1,50))]);
D51	=imresize(C1(:,:,51)	,[494,round(D(1,51))]);
D52	=imresize(C1(:,:,52)	,[494,round(D(1,52))]);
D53	=imresize(C1(:,:,53)	,[494,round(D(1,53))]);
D54	=imresize(C1(:,:,54)	,[494,round(D(1,54))]);
D55	=imresize(C1(:,:,55)	,[494,round(D(1,55))]);
D56	=imresize(C1(:,:,56)	,[494,round(D(1,56))]);
D57	=imresize(C1(:,:,57)	,[494,round(D(1,57))]);
D58	=imresize(C1(:,:,58)	,[494,round(D(1,58))]);
D59	=imresize(C1(:,:,59)	,[494,round(D(1,59))]);
D60	=imresize(C1(:,:,60)	,[494,round(D(1,60))]);
D61	=imresize(C1(:,:,61)	,[494,round(D(1,61))]);
D62	=imresize(C1(:,:,62)	,[494,round(D(1,62))]);
D63	=imresize(C1(:,:,63)	,[494,round(D(1,63))]);
D64	=imresize(C1(:,:,64)	,[494,round(D(1,64))]);
D65	=imresize(C1(:,:,65)	,[494,round(D(1,65))]);
D66	=imresize(C1(:,:,66)	,[494,round(D(1,66))]);
D67	=imresize(C1(:,:,67)	,[494,round(D(1,67))]);
D68	=imresize(C1(:,:,68)	,[494,round(D(1,68))]);
D69	=imresize(C1(:,:,69)	,[494,round(D(1,69))]);
D70	=imresize(C1(:,:,70)	,[494,round(D(1,70))]);
D71	=imresize(C1(:,:,71)	,[494,round(D(1,71))]);
D72	=imresize(C1(:,:,72)	,[494,round(D(1,72))]);
D73	=imresize(C1(:,:,73)	,[494,round(D(1,73))]);
D74	=imresize(C1(:,:,74)	,[494,round(D(1,74))]);
D75	=imresize(C1(:,:,75)	,[494,round(D(1,75))]);
D76	=imresize(C1(:,:,76)	,[494,round(D(1,76))]);
D77	=imresize(C1(:,:,77)	,[494,round(D(1,77))]);
D78	=imresize(C1(:,:,78)	,[494,round(D(1,78))]);
D79	=imresize(C1(:,:,79)	,[494,round(D(1,79))]);
D80	=imresize(C1(:,:,80)	,[494,round(D(1,80))]);

DE1=	double(D1);
DE2=	double(D2);
DE3=	double(D3);
DE4=	double(D4);
DE5=	double(D5);
DE6=	double(D6);
DE7=	double(D7);
DE8=	double(D8);
DE9=	double(D9);
DE10=	double(D10);
DE11=	double(D11);
DE12=	double(D12);
DE13=	double(D13);
DE14=	double(D14);
DE15=	double(D15);
DE16=	double(D16);
DE17=	double(D17);
DE18=	double(D18);
DE19=	double(D19);
DE20=	double(D20);
DE21=	double(D21);
DE22=	double(D22);
DE23=	double(D23);
DE24=	double(D24);
DE25=	double(D25);
DE26=	double(D26);
DE27=	double(D27);
DE28=	double(D28);
DE29=	double(D29);
DE30=	double(D30);
DE31=	double(D31);
DE32=	double(D32);
DE33=	double(D33);
DE34=	double(D34);
DE35=	double(D35);
DE36=	double(D36);
DE37=	double(D37);
DE38=	double(D38);
DE39=	double(D39);
DE40=	double(D40);
DE41=	double(D41);
DE42=	double(D42);
DE43=	double(D43);
DE44=	double(D44);
DE45=	double(D45);
DE46=	double(D46);
DE47=	double(D47);
DE48=	double(D48);
DE49=	double(D49);
DE50=	double(D50);
DE51=	double(D51);
DE52=	double(D52);
DE53=	double(D53);
DE54=	double(D54);
DE55=	double(D55);
DE56=	double(D56);
DE57=	double(D57);
DE58=	double(D58);
DE59=	double(D59);
DE60=	double(D60);
DE61=	double(D61);
DE62=	double(D62);
DE63=	double(D63);
DE64=	double(D64);
DE65=	double(D65);
DE66=	double(D66);
DE67=	double(D67);
DE68=	double(D68);
DE69=	double(D69);
DE70=	double(D70);
DE71=	double(D71);
DE72=	double(D72);
DE73=	double(D73);
DE74=	double(D74);
DE75=	double(D75);
DE76=	double(D76);
DE77=	double(D77);
DE78=	double(D78);
DE79=	double(D79);
DE80=	double(D80);

%���k���ꂽ�摜��494*656�̉摜�ɑ}������
E1 = zeros(494,656,80);
DDD = zeros(1,80);
E2 = zeros(1,80);
E3 = zeros(1,80);
for N=1:80;
DDD(:,N) = rem(round(D(1,N)),2);
if DDD(:,N) == 0;
E2(:,N) = 329-round(round(D(1,N))/2);
E3(:,N) = 328+round(round(D(1,N))/2);
else
    E2(:,N) = 329-round(round(D(1,N))/2);
E3(:,N) = 327+round(round(D(1,N))/2);
end;
end;

E1(1:494,E2(1,1):	E3(1,1)	,1)=	DE1;
E1(1:494,E2(1,2):	E3(1,2)	,2)=	DE2;
E1(1:494,E2(1,3):	E3(1,3)	,3)=	DE3;
E1(1:494,E2(1,4):	E3(1,4)	,4)=	DE4;
E1(1:494,E2(1,5):	E3(1,5)	,5)=	DE5;
E1(1:494,E2(1,6):	E3(1,6)	,6)=	DE6;
E1(1:494,E2(1,7):	E3(1,7)	,7)=	DE7;
E1(1:494,E2(1,8):	E3(1,8)	,8)=	DE8;
E1(1:494,E2(1,9):	E3(1,9)	,9)=	DE9;
E1(1:494,E2(1,10):	E3(1,10)	,10)=	DE10;
E1(1:494,E2(1,11):	E3(1,11)	,11)=	DE11;
E1(1:494,E2(1,12):	E3(1,12)	,12)=	DE12;
E1(1:494,E2(1,13):	E3(1,13)	,13)=	DE13;
E1(1:494,E2(1,14):	E3(1,14)	,14)=	DE14;
E1(1:494,E2(1,15):	E3(1,15)	,15)=	DE15;
E1(1:494,E2(1,16):	E3(1,16)	,16)=	DE16;
E1(1:494,E2(1,17):	E3(1,17)	,17)=	DE17;
E1(1:494,E2(1,18):	E3(1,18)	,18)=	DE18;
E1(1:494,E2(1,19):	E3(1,19)	,19)=	DE19;
E1(1:494,E2(1,20):	E3(1,20)	,20)=	DE20;
E1(1:494,E2(1,21):	E3(1,21)	,21)=	DE21;
E1(1:494,E2(1,22):	E3(1,22)	,22)=	DE22;
E1(1:494,E2(1,23):	E3(1,23)	,23)=	DE23;
E1(1:494,E2(1,24):	E3(1,24)	,24)=	DE24;
E1(1:494,E2(1,25):	E3(1,25)	,25)=	DE25;
E1(1:494,E2(1,26):	E3(1,26)	,26)=	DE26;
E1(1:494,E2(1,27):	E3(1,27)	,27)=	DE27;
E1(1:494,E2(1,28):	E3(1,28)	,28)=	DE28;
E1(1:494,E2(1,29):	E3(1,29)	,29)=	DE29;
E1(1:494,E2(1,30):	E3(1,30)	,30)=	DE30;
E1(1:494,E2(1,31):	E3(1,31)	,31)=	DE31;
E1(1:494,E2(1,32):	E3(1,32)	,32)=	DE32;
E1(1:494,E2(1,33):	E3(1,33)	,33)=	DE33;
E1(1:494,E2(1,34):	E3(1,34)	,34)=	DE34;
E1(1:494,E2(1,35):	E3(1,35)	,35)=	DE35;
E1(1:494,E2(1,36):	E3(1,36)	,36)=	DE36;
E1(1:494,E2(1,37):	E3(1,37)	,37)=	DE37;
E1(1:494,E2(1,38):	E3(1,38)	,38)=	DE38;
E1(1:494,E2(1,39):	E3(1,39)	,39)=	DE39;
E1(1:494,E2(1,40):	E3(1,40)	,40)=	DE40;
E1(1:494,E2(1,41):	E3(1,41)	,41)=	DE41;
E1(1:494,E2(1,42):	E3(1,42)	,42)=	DE42;
E1(1:494,E2(1,43):	E3(1,43)	,43)=	DE43;
E1(1:494,E2(1,44):	E3(1,44)	,44)=	DE44;
E1(1:494,E2(1,45):	E3(1,45)	,45)=	DE45;
E1(1:494,E2(1,46):	E3(1,46)	,46)=	DE46;
E1(1:494,E2(1,47):	E3(1,47)	,47)=	DE47;
E1(1:494,E2(1,48):	E3(1,48)	,48)=	DE48;
E1(1:494,E2(1,49):	E3(1,49)	,49)=	DE49;
E1(1:494,E2(1,50):	E3(1,50)	,50)=	DE50;
E1(1:494,E2(1,51):	E3(1,51)	,51)=	DE51;
E1(1:494,E2(1,52):	E3(1,52)	,52)=	DE52;
E1(1:494,E2(1,53):	E3(1,53)	,53)=	DE53;
E1(1:494,E2(1,54):	E3(1,54)	,54)=	DE54;
E1(1:494,E2(1,55):	E3(1,55)	,55)=	DE55;
E1(1:494,E2(1,56):	E3(1,56)	,56)=	DE56;
E1(1:494,E2(1,57):	E3(1,57)	,57)=	DE57;
E1(1:494,E2(1,58):	E3(1,58)	,58)=	DE58;
E1(1:494,E2(1,59):	E3(1,59)	,59)=	DE59;
E1(1:494,E2(1,60):	E3(1,60)	,60)=	DE60;
E1(1:494,E2(1,61):	E3(1,61)	,61)=	DE61;
E1(1:494,E2(1,62):	E3(1,62)	,62)=	DE62;
E1(1:494,E2(1,63):	E3(1,63)	,63)=	DE63;
E1(1:494,E2(1,64):	E3(1,64)	,64)=	DE64;
E1(1:494,E2(1,65):	E3(1,65)	,65)=	DE65;
E1(1:494,E2(1,66):	E3(1,66)	,66)=	DE66;
E1(1:494,E2(1,67):	E3(1,67)	,67)=	DE67;
E1(1:494,E2(1,68):	E3(1,68)	,68)=	DE68;
E1(1:494,E2(1,69):	E3(1,69)	,69)=	DE69;
E1(1:494,E2(1,70):	E3(1,70)	,70)=	DE70;
E1(1:494,E2(1,71):	E3(1,71)	,71)=	DE71;
E1(1:494,E2(1,72):	E3(1,72)	,72)=	DE72;
E1(1:494,E2(1,73):	E3(1,73)	,73)=	DE73;
E1(1:494,E2(1,74):	E3(1,74)	,74)=	DE74;
E1(1:494,E2(1,75):	E3(1,75)	,75)=	DE75;
E1(1:494,E2(1,76):	E3(1,76)	,76)=	DE76;
E1(1:494,E2(1,77):	E3(1,77)	,77)=	DE77;
E1(1:494,E2(1,78):	E3(1,78)	,78)=	DE78;
E1(1:494,E2(1,79):	E3(1,79)	,79)=	DE79;
E1(1:494,E2(1,80):	E3(1,80)	,80)=	DE80;

%���k�����������P�x��������̂ŁC���k�����{���icos�Ɓj�ŋP�x������
EEE = cos(theta.*(pi)/180);
EE1=zeros(494,656,80);
for N=1:80;
EE1(:,:,N) = E1(:,:,N)./EEE(1,N);%494*656*80
end;

%�T�C�m�O�����̍쐬
R = permute(EE1,[2,3,1]); %�T�C�m�O�����@656*80*494
I = zeros(300,300,300);

%�t���h���ϊ�
for MM=98:397;
I(:,:,MM-97) = iradon(R(:,:,MM),-78:2:80,'Shepp-Logan',0.37,300);
end;

%y�������猩���v���t�@�C��
I0 = abs(I);
I2 = sum(I0,3);
I2_2 = max(max(I2));
I2_3 = 1/I2_2*255*0.75;%�S�Ă̍č\���摜�ɏ�Z���ׂ���
I2_4 = I2.*I2_3;
I1 = I0.*I2_3;
I3 = uint8(I2_4);

%x�������猩���v���t�@�C��
I4=permute(I1,[3,1,2]);%I=462z*462x*494y,I5=494y*462z*462x
I5 = I4(:,300:-1:1,300:-1:1);
I6 = sum(I5,3);
I8 = uint8(I6);

%z�������猩���v���t�@�C��(�č\��)
I9=permute(I1,[3,2,1]);%I=462z*462x*494y,I9=494y*462x*462z
I10 = sum(I9,3);
I11 = uint8(I10);
I12 = I9(:,:,300:-1:1);
I13 = I9(300:-1:1,:,:);

%FromZ�𕽍s�ړ��������̂��A300*300�Ńg���~���O
fromZ = EE1(98:397,179:478,40);
FromZ = I2_3.*fromZ;
FROMZ = uint8(FromZ);

subplot(2,2,1),imshow(I8),title('FromX')
subplot(2,2,2),imshow(I3),title('FromY')
subplot(2,2,3),imshow(FROMZ),title('FromZ')
subplot(2,2,4),imshow(I11),title('FromZfromY')
saveas(gcf,'FromALL300.png')

%�}�Ƃ��ĕۑ�
imwrite(I8,'FROMX300.bmp')
imwrite(I3,'FROMY300.bmp')
imwrite(FROMZ,'FROMZ300.bmp')
imwrite(I11,'FROMZfromY300.bmp')


